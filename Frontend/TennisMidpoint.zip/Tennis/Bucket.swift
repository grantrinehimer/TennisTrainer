import Foundation

class Bucket {
    var name: String
    var date: String
    var link: String
    var bucketImage: String
    
    init(name: String, date: String, link: String, bucketImage: String) {
        self.name = name
        self.date = date
        self.link = link
        self.bucketImage = bucketImage
    }
    

}
